module.exports = {
	'url' : 'mongodb://<dbuser>:<dbpassword>@jello.modulusmongo.net:27017/h9lqenyp'
	//'url' : 'mongodb://localhost/test'
}
